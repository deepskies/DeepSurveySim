# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['telescope_positioning_simulation',
 'telescope_positioning_simulation.IO',
 'telescope_positioning_simulation.Survey']

package_data = \
{'': ['*'], 'telescope_positioning_simulation': ['settings/*']}

install_requires = \
['PyYAML>=6.0,<7.0',
 'astroplan>=0.8,<0.9',
 'matplotlib>=3.7.0,<4.0.0',
 'numexpr>=2.8.4,<3.0.0',
 'numpy>=1.24.2,<2.0.0',
 'pandas>=1.5.3,<2.0.0']

setup_kwargs = {
    'name': 'telescope-positioning-simulation',
    'version': '0.1.0',
    'description': '',
    'long_description': 'None',
    'author': 'voetberg',
    'author_email': 'magpie127@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<3.11',
}


setup(**setup_kwargs)
